//player
let player = [600/2,463];
let colisão= false;
let pontoa = 0;


function playermoves(){
  if(keyIsDown(UP_ARROW)){
    player[1] -= 4;
  }
  if(keyIsDown(DOWN_ARROW)){
    if(limitarmovimentoprabaixo()){
      player[1] += 4;
    }
    
  }
}

function impacto(){
  for (familia = 0;familia < xcarros.length; familia ++){
    colisão = collideRectCircle(xcarros[familia],ycarros[familia],compriEaltu[0],compriEaltu[1],player[0],player[1],16);
  
    pontos(colisão);
  }  
}

function placar(){
  textSize(20);
  textAlign(CENTER);
  fill(color(25, 111, 61));
  text(pontoa,24,30);
  noFill()
  circle(24,22,33);
}

function pontos(){
  
  if(player[1] < 7){
    pontoa +=1;
    player[1]= 463;
    pontoSom.play();
  }
  if(colisão){
    player[1] =463;
    colidir.play();
    pontoa -=1;
  }
  if(pontoa < 0){
    pontoa =0;
  }
  
}


function limitarmovimentoprabaixo(){
  return player[1]<463;
}