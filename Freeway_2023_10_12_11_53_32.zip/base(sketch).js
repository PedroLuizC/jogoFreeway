
function setup() {
  createCanvas(600, 500);
  
}

function draw() {
imagens();
movimentoCarros();
comportamentocarros();
playermoves();
impacto();
placar();
pontos();
}
