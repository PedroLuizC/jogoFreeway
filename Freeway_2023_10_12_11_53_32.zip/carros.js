//listas

let xcarros = [550,550,550,550,550,550];
let ycarros = [330,270,190,60,130,400];
let xvs = [1,4,3,2.5,5,3];
let compriEaltu = [38,38];
let stop = 0;

function movimentoCarros(){
  for(l = 0; l < xcarros.length; l ++){
    xcarros[l] -= xvs[l];
  } 
}

function comportamentocarros(){
    for(c = 0; c < xcarros.length;c ++){
      
    if(passou_do_limite(xcarros[c]))
    xcarros[c] = 600;
  }
function passou_do_limite(xcarros){
    return xcarros <-50;
}
  }
