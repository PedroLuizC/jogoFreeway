//pré jogo
let estrada_jpg;
//player
let player_jpg;
//carros
let carro1;  //verde
let carro2;  //cinza
let carro3;  //amarelo
// som
let colidir;
let pontoSom;
let trilha;

function preload(){
  estrada_jpg = loadImage("imagens/estrada.png");
  player_jpg = loadImage("imagens/ator-1.png");
  carro1 = loadImage("imagens/carro-1.png");
  carro2 = loadImage("imagens/carro-2.png");
  carro3 = loadImage("imagens/carro-3.png");
  carros = [carro1,carro2,carro3,carro1,carro2,carro3];
  colidir = loadSound("som/colidiu.mp3");
  pontoSom = loadSound("som/pontos.wav");
  trilha = loadSound("som/trilha.mp3");
  
}

function setup() {
  createCanvas(600, 500);
  //trilha.loop();
}

function imagens(){
  background(estrada_jpg);
  image(player_jpg,player[0],player[1],32,32);

  for ( p = 0; p < carros.length; p++){
    image(carros[p],xcarros[p],ycarros[p],compriEaltu[0],compriEaltu[1]);
  }
}